# Flaw Loud Central Platform

Server-authoritative account and admin backend for Flaw Loud.

## Security model

- Exactly **one Owner** exists in the database. A partial unique index enforces this at the database layer.
- The Owner is provisioned only from server environment variables on the first boot. There is no public Owner-creation endpoint.
- Public registration always creates `User`.
- Only Owner can promote/demote `Moderator`, suspend/ban users, revoke sessions, reset/ban hardware, reset passwords, and publish release policy.
- Moderator is limited to announcements and report review.
- Passwords are protected with Argon2id.
- Session credentials are 256-bit random opaque tokens; only SHA-256 token hashes are stored server-side.
- Remembered sessions are bound to the device HWID hash and are revocable.
- Raw MachineGuid is never sent to the server; the desktop app sends only an app-specific SHA-256 fingerprint.
- Five failed passwords trigger a 15-minute account lockout.
- Production desktop builds reject non-HTTPS Central Platform URLs (localhost is allowed for development).

## Local test

From the repository root run `RUN_CENTRAL_BACKEND_LOCAL.bat` and choose a private Owner password when prompted. The desktop source is preconfigured for `http://127.0.0.1:8787` during local testing.

On first start the server creates the only Owner account, default username `Bnet`. Other PCs/accounts can only create `User`.

## Production

Use the included Dockerfile. Persist `FLAW_DATA_DIR` with a server volume. Set these server environment variables:

- `FLAW_OWNER_USERNAME=Bnet`
- `FLAW_OWNER_PASSWORD=<private 12+ character password>` (required only when the DB has no Owner yet)
- `FLAW_REGISTRATION_ENABLED=true`
- `FLAW_LATEST_VERSION=1.2.1-rc.4`
- `FLAW_DATA_DIR=/data`

Do not put the Owner password inside the desktop app, Git repository, source ZIP, or frontend.
